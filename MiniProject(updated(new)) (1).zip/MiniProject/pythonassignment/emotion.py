import os
import tkinter as tk
from tkinter import messagebox, ttk


class EmotionDetectorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Emotion Detector")
        self.root.resizable(False, False)

        # Configure a bit of padding
        self.root.columnconfigure(0, weight=1)

        # Mapping from emotion text to image file name
        self.emotion_images = {
            "happy": "happy.png",
            "sad": "sad.png",
            "angry": "angry.png",
            "surprised": "surprised.png",
        }

        self._create_widgets()

    def _create_widgets(self) -> None:
        # Row 0: labels
        self.prompt_label = ttk.Label(
            self.root,
            text="Enter your emotion:",
            anchor="center",
        )
        self.prompt_label.grid(row=0, column=0, padx=10, pady=(10, 2), sticky="ew")

        # Row 1: Entry field
        self.emotion_var = tk.StringVar(value="")
        self.emotion_entry = ttk.Entry(self.root, textvariable=self.emotion_var, width=30)
        self.emotion_entry.grid(row=1, column=0, padx=10, pady=(2, 10), sticky="ew")

        # Row 2: buttons
        buttons_frame = ttk.Frame(self.root)
        buttons_frame.grid(row=2, column=0, padx=10, pady=(0, 10), sticky="ew")

        buttons_frame.columnconfigure(0, weight=1)
        buttons_frame.columnconfigure(1, weight=1)

        self.show_button = ttk.Button(
            buttons_frame,
            text="Your Emotion",
            command=self.show_emotion,
        )
        self.show_button.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="ew")

        self.reset_button = ttk.Button(
            buttons_frame,
            text="Reset",
            command=self.reset_fields,
        )
        self.reset_button.grid(row=0, column=1, padx=(5, 0), pady=5, sticky="ew")

        # Focus on the text field at startup
        self.emotion_entry.focus_set()

    def show_emotion(self) -> None:
        emotion_raw = self.emotion_var.get().strip()

        if not emotion_raw:
            messagebox.showwarning("Missing Emotion", "Please enter an emotion first.")
            return

        emotion_key = emotion_raw.lower()
        image_file = self.emotion_images.get(emotion_key)

        if not image_file:
            messagebox.showinfo(
                "Unknown Emotion",
                f"No image configured for emotion: {emotion_raw}",
            )
            return

        # Build absolute path
        script_dir = os.path.dirname(os.path.abspath(__file__))
        img_path = os.path.join(script_dir, image_file)

        img = None
        load_error: Exception | None = None

        try:
            from PIL import Image, ImageTk  # type: ignore

            try:
                pil_img = Image.open(img_path)
                img = ImageTk.PhotoImage(pil_img)
            except Exception as exc:
                load_error = exc

        except Exception:
            try:
                img = tk.PhotoImage(file=img_path)
            except Exception as exc:
                load_error = exc

        if img is None:
            messagebox.showerror(
                "Image Error",
                "Could not load the image for your emotion.\n\n"
                f"Expected file: {img_path}\n\n"
                f"Details: {load_error}",
            )
            return

        popup = tk.Toplevel(self.root)
        popup.title(f"Your emotion: {emotion_raw}")
        popup.resizable(False, False)

        # Prevent garbage collection
        popup.img_ref = img

        img_label = ttk.Label(popup, image=img)
        img_label.pack(padx=10, pady=10)

        close_button = ttk.Button(popup, text="Close", command=popup.destroy)
        close_button.pack(pady=(0, 10))

        self._center_window(popup)

    def reset_fields(self) -> None:
        self.emotion_var.set("")
        self.prompt_label.config(text="Enter your emotion:")
        self.emotion_entry.focus_set()

    def _center_window(self, win: tk.Toplevel) -> None:
        win.update_idletasks()

        w = win.winfo_width()
        h = win.winfo_height()

        x_root = self.root.winfo_x()
        y_root = self.root.winfo_y()

        root_w = self.root.winfo_width()
        root_h = self.root.winfo_height()

        x = x_root + (root_w // 2) - (w // 2)
        y = y_root + (root_h // 2) - (h // 2)

        win.geometry(f"{w}x{h}+{x}+{y}")


def main() -> None:
    root = tk.Tk()
    EmotionDetectorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()